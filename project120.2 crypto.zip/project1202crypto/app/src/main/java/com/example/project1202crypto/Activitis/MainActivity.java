package com.example.project1202crypto.Activitis;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.example.project1202crypto.Adapter.CryptoWalletAdapter;
import com.example.project1202crypto.Domain.CryptoWallet;
import com.example.project1202crypto.R;
import com.example.project1202crypto.databinding.ActivityMainBinding;
import com.google.firebase.FirebaseApp;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView.Adapter adapter;
    private RecyclerView recyclerView;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inicializar o binding
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        FirebaseApp.initializeApp(this);
        recyclerViewWallet();

        // Definir listener de clique para o botão de perfil
        binding.imageView42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirecionar para PerfilActivity
                Intent intent = new Intent(MainActivity.this, PerfilActivity.class);
                startActivity(intent);
            }
        });

        // Receber o nome do usuário cadastrado
        Intent intent = getIntent();
        String nomeUsuario = intent.getStringExtra("nomeUsuario");
        if (nomeUsuario != null) {
            binding.textView9.setText(nomeUsuario);
        }


    }


    private void recyclerViewWallet() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView = binding.view; // Usar binding ao invés de findViewById
        recyclerView.setLayoutManager(linearLayoutManager);

        ArrayList<CryptoWallet> cryptoWalletArrayList = new ArrayList<>();
        ArrayList<Integer> lineData = new ArrayList<>();
        lineData.add(1000);
        lineData.add(1100);
        lineData.add(1200);
        lineData.add(1100);

        ArrayList<Integer> lineData2 = new ArrayList<>();
        lineData2.add(2100);
        lineData2.add(2000);
        lineData2.add(1900);
        lineData2.add(2000);

        ArrayList<Integer> lineData3 = new ArrayList<>();
        lineData3.add(900);
        lineData3.add(1100);
        lineData3.add(1200);
        lineData3.add(1000);
        lineData3.add(1150);

        cryptoWalletArrayList.add(new CryptoWallet("bitcoin", "BTX", 1234.12, 2.13, lineData, 1234.12, 0.12343));
        cryptoWalletArrayList.add(new CryptoWallet("etherium", "ETH", 2134.21, -1.13, lineData2, 6545.65, 0.01245));
        cryptoWalletArrayList.add(new CryptoWallet("trox", "ROX", 6543.21, 0.73, lineData3, 31234.12, 0.02154));

        adapter = new CryptoWalletAdapter(cryptoWalletArrayList);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
