package com.example.project1202crypto.Activitis;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.project1202crypto.Activitis.IntroActivity;
import com.example.project1202crypto.Activitis.MainActivity;
import com.example.project1202crypto.databinding.ActivityPerfilBinding;

public class PerfilActivity extends AppCompatActivity {

    private ActivityPerfilBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inicializar o binding
        binding = ActivityPerfilBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        // Definir listeners de clique para os botões
        binding.alterarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Código para alterar a imagem do perfil
            }
        });

        binding.SairContaBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirecionar para IntroActivity
                Intent intent = new Intent(PerfilActivity.this, IntroActivity.class);
                startActivity(intent);
            }
        });

        binding.imageView38.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirecionar para MainActivity
                Intent intent = new Intent(PerfilActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
