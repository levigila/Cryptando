package com.example.project1202crypto.Activitis.view.formLogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.project1202crypto.Activitis.MainActivity;
import com.example.project1202crypto.Activitis.view.formCadastro.CadastroActivity;
import com.example.project1202crypto.R;
import com.example.project1202crypto.databinding.ActivityLoginBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    private EditText userEdt, passEdt;
    private Button loginBtn;
    private ActivityLoginBinding binding; // Declare binding variable
    private FirebaseAuth auth; // Declare FirebaseAuth

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize binding and set content view
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize FirebaseAuth
        auth = FirebaseAuth.getInstance();

        // Initialize views and set click listeners
        setupClickListeners();
        initView();
        setVariable();
    }

    private void setupClickListeners() {
        binding.registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, CadastroActivity.class);
                startActivity(intent);
            }
        });
    }

    private void initView() {
        userEdt = binding.editTextTextPersonName;
        passEdt = binding.editTextTextPassword;
        loginBtn = binding.loginBtn; // Correct the button ID
    }

    private boolean isEmpty(String... fields) {
        for (String field : fields) {
            if (field == null || field.isEmpty()) {
                return true;
            }
        }
        return false;
    }
    private void setVariable() {
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = userEdt.getText().toString().trim();
                String password = passEdt.getText().toString().trim();

                // Check for empty fields
                if (isEmpty(email, password)) {
                    showEmptyFieldErrorSnackbar(v);
                }  else {
                    loginUser(v, email, password);
                }
            }

    private void loginUser(View view, String email, String password) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        // Login successful
                        Log.d("LoginActivity", "signInWithEmailAndPassword:success");
                        showLoginSuccessSnackbar(view);
                        // Navigate to MainActivity
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        // Login failed
                        Log.w("LoginActivity", "signInWithEmailAndPassword:failure", task.getException());
                        showInvalidCredentialsSnackbar(view);
                    }
                }
            });
            }

            // mensagem de sucesso
    private void showLoginSuccessSnackbar(View view) {
        Snackbar snackbar = Snackbar.make(view, "Login realizado com sucesso!", Snackbar.LENGTH_SHORT);
        snackbar.setBackgroundTint(Color.GREEN); // Set background color for success
        snackbar.show();
            }

            // mensagem de erro -> email ou senha invalido
    private void showInvalidCredentialsSnackbar(View view) {
        Snackbar snackbar = Snackbar.make(view, "E-mail ou senha inválidos!", Snackbar.LENGTH_SHORT);
        snackbar.setBackgroundTint(Color.RED); // Set background color for error
        snackbar.show();
            }

            // mensagem de erro -> campos vazios
    private void showEmptyFieldErrorSnackbar(View view) {
        Snackbar snackbar = Snackbar.make(view, "Preencha todos os campos!", Snackbar.LENGTH_SHORT);
        snackbar.setBackgroundTint(Color.RED); // Set background color for error
        snackbar.show();
            }

        });
    }
}