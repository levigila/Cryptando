package com.example.project1202crypto.Activitis;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.project1202crypto.R;

public class CadastroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
    }
}