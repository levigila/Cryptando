package com.example.project1202crypto.Activitis.view.formCadastro;

import static android.text.TextUtils.isEmpty;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.project1202crypto.Activitis.MainActivity;
import com.example.project1202crypto.Activitis.view.formLogin.LoginActivity;
import com.example.project1202crypto.databinding.ActivityCadastroBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class CadastroActivity extends AppCompatActivity {

    private ActivityCadastroBinding binding;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCadastroBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        auth = FirebaseAuth.getInstance();

        // Set click listener for "Fazer Login" button
        binding.loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to LoginActivity
                Intent intent = new Intent(CadastroActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        // Set click listener for registration button
        binding.registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = binding.editTextTextPersonUser.getText().toString().trim();
                String email = binding.editTextTextEmail.getText().toString().trim();
                String senha = binding.editTextTextSenha.getText().toString().trim();

                // Check if any fields are empty
                if (isEmpty(nome) || isEmpty(email) || isEmpty(senha)) {
                    showEmptyFieldErrorSnackbar(view);
                } else {
                    // Cadastra o usuario com email e senha
                    auth.createUserWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Show the success message and navigate to LoginActivity
                                showRegistrationSuccessSnackbar(view);

                                //envia o nome para o main
                                Intent intent = new Intent(CadastroActivity.this, MainActivity.class);
                                intent.putExtra("nomeUsuario", nome);
                                startActivity(intent);
                                finish();

                                // Navigate to LoginActivity
                                Intent intent2 = new Intent(CadastroActivity.this, LoginActivity.class);
                                startActivity(intent2);
                                finish();
                            }
                        }
                    });
                }
            }
        });
    }


    private void showEmptyFieldErrorSnackbar(View view) {
        Snackbar snackbar = Snackbar.make(view, "Preencha todos os campos!", Snackbar.LENGTH_SHORT);
        snackbar.setBackgroundTint(Color.RED);
        snackbar.show();
    }

    private void showRegistrationSuccessSnackbar(View view) {
        Snackbar snackbar = Snackbar.make(view, "Cadastro realizado com sucesso!", Snackbar.LENGTH_SHORT);
        snackbar.setBackgroundTint(Color.GREEN);
        snackbar.show();
    }
}
